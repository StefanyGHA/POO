const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com', 
    port: 465, 
    secure: true, 
    auth: {
        user: 'hernandezarguetas@gmail.com', 
        pass: 'zywj rrac qhyf ztrc' 
    }
});


class Correo {
    constructor(destinatario, asunto, cuerpo) {
        this.destinatario = destinatario;
        this.asunto = asunto;
        this.cuerpo = cuerpo;
    }

    async enviar() {
        try {
           
            const mailOptions = {
                from: 'hernandezarguetas@gmail.com', 
                to: this.destinatario, 
                subject: this.asunto, 
                html: this.cuerpo 
            };

            const info = await transporter.sendMail(mailOptions);
            console.log('Correo enviado:', info.messageId);
        } catch (error) {
            console.error('Error al enviar el correo:', error);
        }
    }
}

const miCorreo = new Correo('j.william03@hotmail.com', 'Se supone que pude Ing.', '<p>Ya tengo mi tarea lista para subir, aunque no me funcione el enviar del index :(</p>');
miCorreo.enviar()

